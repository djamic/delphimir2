
# hash value = 375221
mitec_strutils.rstrue='True'


# hash value = 5014421
mitec_strutils.rsfalse='False'

